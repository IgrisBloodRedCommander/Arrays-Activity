/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sumandavearage;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class SumAndAvearage {

/*
* Name: Lex Edrick Asherjesse C. Matondo
* Course: Computer Engineering - First Year
* Lab Activity: Array Implementation and For Loop Practice - Problem 1
* Submittion Date: November, 07, 2024
*/
    
 // Sample Input:
// 5 10 15 20 25 30 35 40 45 50

// Sample Output:
// The Numbers that you entered: 5  10  15  20  25  30  35  40  45  50  
// Sum of The Numbers That You Entered: 275  
// The Average: 27.5

    public static void main(String[] args) {
        boolean again = true; //declared 'again' as true to be able to let user to input again, it is put inside a while loop
        while (again) {
            int[] numbers = new int[10]; //an array with 10 elements that will be later stored
            int total = 0;
            String enteredNumbers = ""; //this will store the numbers that the user will input
            boolean usab = true; 
            while (usab) {
                for (int i = 0; i < 10; i++) { // the for loop
                    String num = JOptionPane.showInputDialog(null, "Enter number " + (i + 1) + ":", "Sum And Average Calculator", JOptionPane.PLAIN_MESSAGE);
                                   if (num == null) {
                    usab = false;
                    again = false;
                    int piliBruh = JOptionPane.showConfirmDialog(null, "Do You Want to Exit?\n"); //asks user if he/she will exit
                    switch (piliBruh) {
                        case -1:
                        case 0:  
                            JOptionPane.showMessageDialog(null, "Thank You For Using This Program"); //the response if the user chose to exit
                            System.exit(0);
                            break;
                        case 1:  
                            usab = true;
                            break;
                        case 2:  
                            usab = true;
                            break;
                        default:
                            break;
                    }
                    if (!usab) break; 
                } else {
                    try {numbers[i] = Integer.parseInt(num);
                    total += numbers[i];
                    enteredNumbers += numbers[i] + "  "; //this will store the entered numbers
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    i--; continue; 
                    
                }
                                   }         
                } 
                    if (usab){
                        double av = total / 10;
                        String[] set = {"Enter Numbers Again", "Exit"};
                        int shesh = JOptionPane.showOptionDialog(null, "The Numbers that you entered: " + enteredNumbers + "\nSum of The Numbers That You Entered: " + total + "\nThe Average: " + av, "Sum and Avearage Calculator", JOptionPane.DEFAULT_OPTION, -1, null, set, set[0]);
                        switch (shesh) {
                            case 0:
                                again = true;
                               total=0;
                                enteredNumbers="";
                                break;
                            case 1:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                again = false;
                                System.exit(0);
                                break;
                            case -1:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                again = false;
                                System.exit(0);
                                break;
                        }

                    }
                
            
        }
    }
}
}
