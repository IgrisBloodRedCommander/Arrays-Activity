/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rev;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Rev {

 /*
* Name: Lex Edrick Asherjesse C. Matondo
* Course: Computer Engineering - First Year
* Lab Activity: Array Implementation and For Loop Practice - Problem 3
* Submittion Date: December,07, 2024
*/
    
// Sample Input:
// 5 10 15 20 25

// Sample Output:
// The Numbers that you entered: 5.0  10.0  15.0  20.0  25.0  
// The Reverse Order of The Elements:  25.0  20.0  15.0  10.0  5.0
    
    
    public static void main(String[] args) {
          boolean again = true; //declared 'again' as true to be able to let user to input again, it is put inside a while loop
        while (again) {
            float[] numbers = new float[5]; //an array with 5 elements that will be later stored

            String enteredNumbers = ""; //this will store the numbers that the user will input
            boolean usab = true;
            while (usab) {
                for (int i = 0; i < 5; i++) {
                    String num = JOptionPane.showInputDialog(null, "Enter number " + (i + 1) + ":", "Reverse Order", JOptionPane.PLAIN_MESSAGE);

                    if (num == null) {
                        usab = false;
                        again = false;
                        int piliBruh = JOptionPane.showConfirmDialog(null, "Do You Want to Exit?\n");
                        switch (piliBruh) {
                            case -1:
                            case 0:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                System.exit(0);
                                break;
                            case 1:
                                usab = true;
                                break;
                            case 2:
                                usab = true;
                                break;
                            default:
                                break;
                        }
                        if (!usab) {
                            break;
                        }
                    } else {
                        try {
                            numbers[i] = Float.parseFloat(num);

                            enteredNumbers += numbers[i] + "  ";
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                            i--;

                        }
                    }
                }
                if (usab) {
                    String reversed = "";
                    for (int i = numbers.length - 1; i >= 0; i--) {
                        reversed += numbers[i] + "  ";
                    }
                    String[] set = {"Enter Numbers Again", "Exit"};
                    int shesh = JOptionPane.showOptionDialog(null, "The Numbers that you entered: " + enteredNumbers + "\nThe Reverse Order of The Elements:  " + reversed, "Minimum And Maximum", JOptionPane.DEFAULT_OPTION, -1, null, set, set[0]);
                    switch (shesh) {
                        case 0:
                            again = true;

                            enteredNumbers = "";
                            break;
                        case 1:
                            JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                            again = false;
                            System.exit(0);
                            break;
                        case -1:
                            JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                            again = false;
                            System.exit(0);
                            break;
                    }

                }

            }
        }
    }
    
}
