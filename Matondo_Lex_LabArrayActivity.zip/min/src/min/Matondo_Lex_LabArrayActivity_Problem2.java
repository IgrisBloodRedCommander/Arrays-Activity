/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package min;

import javax.swing.JOptionPane;

/*
 * Name: Lex Edrick Asherjesse C. Matondo
 * Course: Computer Engineering - First Year
 * Lab Activity: Array Implementation and For Loop Practice - Problem 2
 * Submittion Date: December,07, 2024
 */

// Sample Input:
// 5 10 15 20 25 30 35 40 45 50

// Sample Output:
// Sum of array: 275
// Average of array: 27.5

public class Min {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        boolean again = true; //declared 'again' as true to be able to let user to input again, it is put inside a while loop
        while (again) {
            int[] numbers = new int[15]; //an array with 15 elements that will be later stored
           
            String enteredNumbers = ""; //this will store the numbers that the user will input
            boolean usab = true;
            while (usab) {
                for (int i = 0; i < 15; i++) {
                    String num = JOptionPane.showInputDialog(null, "Enter number " + (i + 1) + ":", "Minimum And Maximum", JOptionPane.PLAIN_MESSAGE);
                           
                           if (num == null) {
                    usab = false;
                    again = false;
                    int piliBruh = JOptionPane.showConfirmDialog(null, "Do You Want to Exit?\n"); //asks user if he/she will exit
                    switch (piliBruh) {
                        case -1:
                        case 0:  
                            JOptionPane.showMessageDialog(null, "Thank You For Using This Program");  //the response if the user chose to exit
                            System.exit(0);
                            break;
                        case 1:  
                            usab = true;
                            break;
                        case 2:  
                            usab = true;
                            break;
                        default:
                            break;
                    }
                    if (!usab) break; 
                } else {
                    try {numbers[i] = Integer.parseInt(num);
               
                    enteredNumbers += numbers[i] + "  "; //this will store the entered numbers
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    i--; 
                    
                }
                                   }         
                } 
                    if (usab){
                        double max = numbers[0];
                         double min = numbers[0];
                         for (int i = 1; i<numbers.length; i++){ //the for loop
                        if (numbers[i]>max) {
                            max= numbers[i];
                        }
                        if (numbers[i]<min) {
                            min= numbers[i];
                        }}
                        String[] set = {"Enter Numbers Again", "Exit"}; 
                        int shesh = JOptionPane.showOptionDialog(null, "The Numbers that you entered: " + enteredNumbers + "\nThe Mimimum Element: " + min +"\nThe Maximum Element: "+ max, "Minimum And Maximum", JOptionPane.DEFAULT_OPTION, -1, null, set, set[0]);
                        switch (shesh) {
                            case 0:
                                again = true;
                       
                                enteredNumbers="";
                                break;
                            case 1:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                again = false;
                                System.exit(0);
                                break;
                            case -1:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                again = false;
                                System.exit(0);
                                break;
                        }

                    }
                
            
        }
    }
    }
    
}
