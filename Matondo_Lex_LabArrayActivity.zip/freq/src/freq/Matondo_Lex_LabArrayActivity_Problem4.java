/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package freq;

import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Matondo_Lex_LabArrayActivity_Problem4 {

   /*
* Name: Lex Edrick Asherjesse C. Matondo
* Course: Computer Engineering - First Year
* Lab Activity: Array Implementation and For Loop Practice - Problem 4
* Submittion Date: December, 07, 2024 
*/
    
 // Sample Input:
// 5 10 15 20 25 30 35 40 45 50

// Sample Output:
// The Numbers that you entered: 5  10  15  20  25  30  35  40  45  50  
// Input value to find its Frequency: 25
// The Frequency of the number 25 is: 1
    
    public static void main(String[] args) {
       boolean again = true; //declared 'again' as true to be able to let user to input again, it is put inside a while loop
        while (again) {
            int[] numbers = new int[10]; //an array with 10 elements that will be later stored
            String enteredNumbers = ""; //this will store the numbers that the user will input
            boolean usab = true;
            while (usab) {
                for (int i = 0; i < 10; i++) {
                    String num = JOptionPane.showInputDialog(null, "Enter 10 integers between 1-100\n\nNumber " + (i + 1) + ":", "Frequency Finder", JOptionPane.PLAIN_MESSAGE);
                    int limit = Integer.parseInt(num);

                    if (num == null) {
                        usab = false;
                        again = false;
                        int piliBruh = JOptionPane.showConfirmDialog(null, "Do You Want to Exit?\n"); //asks user if he/she will exit
                        switch (piliBruh) {
                            case -1:
                            case 0:
                                JOptionPane.showMessageDialog(null, "Thank You For Using This Program"); //the response if the user chose to exit
                                System.exit(0);
                                break;
                            case 1:
                                usab = true;
                                break;
                            case 2:
                                usab = true;
                                break;
                            default:
                                break;
                        }
                        if (!usab) {
                            break;
                        }
                    } else {
                        try {
                            numbers[i] = Integer.parseInt(num);
                            enteredNumbers += numbers[i] + "  "; //this will store the entered numbers
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                            i--;

                        }
                    }
                    if (limit > 100 || limit < 0) {
                        JOptionPane.showMessageDialog(null, "Invalid input. Please enter values between 1-100.", "Error", JOptionPane.ERROR_MESSAGE);
                        i--;
                    }
                } 

                boolean enterAgain = true;
                while (enterAgain) {
                    String shesh1 = JOptionPane.showInputDialog(null, "The Numbers that you entered: " + enteredNumbers + "\nInput value to find its Frequency: ", "Minimum And Maximum", JOptionPane.DEFAULT_OPTION);
                    if (shesh1 != null) {
                        try {
                            int freq = Integer.parseInt(shesh1);
                            int frequency = 0;
                            for (int num : numbers) {
                                if (num == freq) {
                                    frequency++;
                                }
                            }
                            String[] set = {"Enter Numbers Again", "Another Frequency of A Number", "Exit"};
                            int shesh = JOptionPane.showOptionDialog(null, "The Numbers that you entered: " + enteredNumbers + "\nThe number that you entered: " + freq + "\nThe Frequency:  " + frequency, "Frequency Result", JOptionPane.DEFAULT_OPTION, -1, null, set, set[0]);
                            switch (shesh) {
                                case 0:
                                    again = true;

                                    enteredNumbers = "";
                                    break;
                                case 2:
                                    JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                    again = false;
                                    enterAgain = false;
                                    System.exit(0);
                                    break;
                                case -1:
                                    JOptionPane.showMessageDialog(null, "Thank You For Using This Program");
                                    again = false;
                                    System.exit(0);
                                    break;
                                case 1:
                                    enterAgain = true;
                                    break;

                            }
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }  
                   
                }
            }
        }
    }
    
}
